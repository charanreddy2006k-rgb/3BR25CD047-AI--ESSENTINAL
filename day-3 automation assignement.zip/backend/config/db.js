const { Pool } = require('pg');

const pool = new Pool({
  user: 'jules',
  host: 'localhost',
  database: 'bitm_erp',
  password: 'password',
  port: 5432,
});

module.exports = {
  query: (text, params) => pool.query(text, params),
};
