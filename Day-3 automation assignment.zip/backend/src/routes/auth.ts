import { Router } from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { getQuery } from '../db';
import dotenv from 'dotenv';
dotenv.config();

const router = Router();
const JWT_SECRET = process.env.JWT_SECRET || 'bitm_super_secret_key_2026';

router.post('/login', async (req, res) => {
  const { identifier, password } = req.body;

  try {
    let user;
    
    const student = await getQuery(`SELECT user_id FROM Students WHERE usn = ?`, [identifier]);
    
    if (student) {
       user = await getQuery(`SELECT * FROM Users WHERE id = ?`, [student.user_id]);
    } else {
       user = await getQuery(`SELECT * FROM Users WHERE email = ?`, [identifier]);
    }

    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    if (user.status !== 'ACTIVE') {
      return res.status(403).json({ error: 'Account is deactivated' });
    }

    let studentData = null;
    if (user.role === 'STUDENT') {
      studentData = await getQuery(`SELECT * FROM Students WHERE user_id = ?`, [user.id]);
    }

    const token = jwt.sign({ id: user.id, role: user.role, name: user.name, studentId: studentData?.id, usn: studentData?.usn }, JWT_SECRET, { expiresIn: '1d' });

    res.json({
      token,
      user: {
        id: user.id,
        name: user.name,
        role: user.role,
        email: user.email,
        student: studentData
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error during login' });
  }
});

export default router;
