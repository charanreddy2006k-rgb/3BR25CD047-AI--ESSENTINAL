import { Router } from 'express';
import { getQuery, allQuery, runQuery } from '../db';
import { authenticateToken, requireRole, AuthRequest } from '../middleware';

const router = Router();

// Finance: Get all payments
router.get('/payments', authenticateToken, requireRole(['FINANCE', 'SUPER_ADMIN']), async (req: AuthRequest, res) => {
  try {
    const payments = await allQuery(`
      SELECT p.*, s.name, s.usn, r.receipt_number
      FROM Payments p
      JOIN Students s ON p.student_id = s.id
      LEFT JOIN Receipts r ON p.id = r.payment_id
      ORDER BY p.payment_date DESC
    `);
    res.json(payments);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Admin: Get Dashboard Stats
router.get('/stats', authenticateToken, requireRole(['FINANCE', 'SUPER_ADMIN', 'EXAM']), async (req: AuthRequest, res) => {
  try {
    const totalStudents = await getQuery(`SELECT COUNT(*) as count FROM Students`);
    const totalPayments = await getQuery(`SELECT COUNT(*) as count FROM Payments`);
    const successfulPayments = await getQuery(`SELECT COUNT(*) as count FROM Payments WHERE status = 'SUCCESS'`);
    const collection = await getQuery(`SELECT SUM(amount) as total FROM Payments WHERE status = 'SUCCESS'`);
    const registrations = await getQuery(`SELECT COUNT(*) as count FROM Registrations WHERE registration_status = 'COMPLETED'`);
    const hallTickets = await getQuery(`SELECT COUNT(*) as count FROM HallTickets WHERE availability_status = 'AVAILABLE'`);

    res.json({
      totalStudents: totalStudents.count,
      totalPayments: totalPayments.count,
      successfulPayments: successfulPayments.count,
      totalCollection: collection.total || 0,
      totalRegistrations: registrations.count,
      publishedHallTickets: hallTickets.count
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Exam: Get Registrations
router.get('/registrations', authenticateToken, requireRole(['EXAM', 'SUPER_ADMIN']), async (req: AuthRequest, res) => {
  try {
    const registrations = await allQuery(`
      SELECT r.*, s.name, s.usn, s.branch 
      FROM Registrations r
      JOIN Students s ON r.student_id = s.id
    `);
    res.json(registrations);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Exam: Update Registration Status
router.post('/registrations/update', authenticateToken, requireRole(['EXAM', 'SUPER_ADMIN']), async (req: AuthRequest, res) => {
  const { id, status } = req.body;
  try {
    await runQuery(`UPDATE Registrations SET registration_status = ? WHERE id = ?`, [status, id]);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Exam: Publish Hall Ticket
router.post('/halltickets/publish', authenticateToken, requireRole(['EXAM', 'SUPER_ADMIN']), async (req: AuthRequest, res) => {
  const { examination, exam_date, exam_center } = req.body;
  try {
    // Generate hall ticket for all active students for demo
    const students = await allQuery(`SELECT id FROM Students`);
    for (const student of students) {
      await runQuery(`
        INSERT INTO HallTickets (student_id, examination, exam_date, exam_center, availability_status)
        VALUES (?, ?, ?, ?, 'AVAILABLE')
      `, [student.id, examination, exam_date, exam_center]);
    }
    
    // Audit Log
    await runQuery(`
      INSERT INTO AuditLogs (user_id, action, new_value)
      VALUES (?, ?, ?)
    `, [req.user.id, 'PUBLISH_HALL_TICKETS', JSON.stringify({ examination, count: students.length })]);

    res.json({ success: true, published: students.length });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
