import { Router } from 'express';
import { getQuery, allQuery, runQuery } from '../db';
import { authenticateToken, requireRole, AuthRequest } from '../middleware';

const router = Router();

// Get payment history for a student
router.get('/history', authenticateToken, requireRole(['STUDENT']), async (req: AuthRequest, res) => {
  try {
    const payments = await allQuery(`
      SELECT p.*, r.receipt_number 
      FROM Payments p 
      LEFT JOIN Receipts r ON p.id = r.payment_id 
      WHERE p.student_id = ?
      ORDER BY p.payment_date DESC
    `, [req.user.studentId]);
    res.json(payments);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Process a new payment (Demo)
router.post('/process', authenticateToken, requireRole(['STUDENT']), async (req: AuthRequest, res) => {
  const { fee_category, amount, payment_method } = req.body;
  const studentId = req.user.studentId;

  try {
    const txnId = 'TXN' + Math.floor(Math.random() * 1000000000);
    
    // Create Payment
    const paymentResult = await runQuery(`
      INSERT INTO Payments (transaction_id, student_id, fee_category, amount, payment_method, status)
      VALUES (?, ?, ?, ?, ?, 'SUCCESS')
    `, [txnId, studentId, fee_category, amount, payment_method]);

    // Create Receipt
    const recNo = 'REC' + new Date().getFullYear() + String(paymentResult.id).padStart(4, '0');
    const receiptResult = await runQuery(`
      INSERT INTO Receipts (receipt_number, payment_id, student_id)
      VALUES (?, ?, ?)
    `, [recNo, paymentResult.id, studentId]);

    // Audit Log
    await runQuery(`
      INSERT INTO AuditLogs (user_id, action, record_id, new_value)
      VALUES (?, ?, ?, ?)
    `, [req.user.id, 'PAYMENT_PROCESSED', paymentResult.id, JSON.stringify({ txnId, amount, status: 'SUCCESS' })]);

    res.json({ success: true, transaction_id: txnId, receipt_number: recNo, payment_id: paymentResult.id });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Payment processing failed' });
  }
});

// Get receipt details
router.get('/receipt/:receiptNumber', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const receipt = await getQuery(`
      SELECT r.*, p.transaction_id, p.fee_category, p.amount, p.payment_method, p.payment_date, p.status,
             s.name, s.usn, s.branch, s.semester, s.academic_year
      FROM Receipts r
      JOIN Payments p ON r.payment_id = p.id
      JOIN Students s ON r.student_id = s.id
      WHERE r.receipt_number = ?
    `, [req.params.receiptNumber]);

    if (!receipt) return res.status(404).json({ error: 'Receipt not found' });

    // Authorization check
    if (req.user.role === 'STUDENT' && receipt.student_id !== req.user.studentId) {
      return res.status(403).json({ error: 'Access denied' });
    }

    res.json(receipt);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
