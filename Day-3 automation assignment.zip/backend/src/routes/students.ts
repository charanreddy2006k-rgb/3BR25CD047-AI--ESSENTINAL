import { Router } from 'express';
import { getQuery, allQuery } from '../db';
import { authenticateToken, requireRole, AuthRequest } from '../middleware';

const router = Router();

// Get student profile
router.get('/profile', authenticateToken, requireRole(['STUDENT']), async (req: AuthRequest, res) => {
  try {
    const student = await getQuery(`SELECT * FROM Students WHERE user_id = ?`, [req.user.id]);
    if (!student) return res.status(404).json({ error: 'Student not found' });
    res.json(student);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get bus details
router.get('/bus', authenticateToken, requireRole(['STUDENT']), async (req: AuthRequest, res) => {
  try {
    const bus = await getQuery(`SELECT * FROM Bus WHERE student_id = ?`, [req.user.studentId]);
    res.json(bus || null);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get hostel details
router.get('/hostel', authenticateToken, requireRole(['STUDENT']), async (req: AuthRequest, res) => {
  try {
    const hostel = await getQuery(`SELECT * FROM Hostel WHERE student_id = ?`, [req.user.studentId]);
    res.json(hostel || null);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get higher sem registration
router.get('/registration', authenticateToken, requireRole(['STUDENT']), async (req: AuthRequest, res) => {
  try {
    // using latest registration based on id desc
    const registration = await getQuery(`SELECT * FROM Registrations WHERE student_id = ? ORDER BY id DESC LIMIT 1`, [req.user.studentId]);
    res.json(registration || null);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get hall tickets
router.get('/halltickets', authenticateToken, requireRole(['STUDENT']), async (req: AuthRequest, res) => {
  try {
    const tickets = await allQuery(`SELECT * FROM HallTickets WHERE student_id = ?`, [req.user.studentId]);
    res.json(tickets);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
