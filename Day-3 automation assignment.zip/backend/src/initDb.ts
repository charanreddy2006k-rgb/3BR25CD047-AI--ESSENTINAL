import db, { runQuery } from './db';
import bcrypt from 'bcryptjs';

const initDb = async () => {
  try {
    // 1. Users Table
    await runQuery(`
      CREATE TABLE IF NOT EXISTS Users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('STUDENT', 'FINANCE', 'EXAM', 'SUPER_ADMIN')),
        status TEXT DEFAULT 'ACTIVE'
      )
    `);

    // 2. Students Table
    await runQuery(`
      CREATE TABLE IF NOT EXISTS Students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER UNIQUE,
        usn TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        phone TEXT,
        branch TEXT NOT NULL,
        semester TEXT NOT NULL,
        academic_year TEXT NOT NULL,
        admission_category TEXT,
        FOREIGN KEY (user_id) REFERENCES Users(id)
      )
    `);

    // 3. Payments Table
    await runQuery(`
      CREATE TABLE IF NOT EXISTS Payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        transaction_id TEXT UNIQUE,
        student_id INTEGER,
        fee_category TEXT NOT NULL,
        amount REAL NOT NULL,
        payment_method TEXT,
        payment_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        status TEXT NOT NULL DEFAULT 'PENDING',
        FOREIGN KEY (student_id) REFERENCES Students(id)
      )
    `);

    // 4. Receipts Table
    await runQuery(`
      CREATE TABLE IF NOT EXISTS Receipts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        receipt_number TEXT UNIQUE NOT NULL,
        payment_id INTEGER,
        student_id INTEGER,
        generated_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        receipt_url TEXT,
        FOREIGN KEY (payment_id) REFERENCES Payments(id),
        FOREIGN KEY (student_id) REFERENCES Students(id)
      )
    `);

    // 5. Registration Table
    await runQuery(`
      CREATE TABLE IF NOT EXISTS Registrations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER,
        semester TEXT NOT NULL,
        academic_year TEXT NOT NULL,
        registration_status TEXT DEFAULT 'NOT_STARTED',
        payment_status TEXT DEFAULT 'PENDING',
        FOREIGN KEY (student_id) REFERENCES Students(id)
      )
    `);

    // 6. Bus Table
    await runQuery(`
      CREATE TABLE IF NOT EXISTS Bus (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER UNIQUE,
        route TEXT,
        pickup_point TEXT,
        academic_year TEXT,
        fee REAL,
        payment_status TEXT DEFAULT 'PENDING',
        FOREIGN KEY (student_id) REFERENCES Students(id)
      )
    `);

    // 7. Hostel Table
    await runQuery(`
      CREATE TABLE IF NOT EXISTS Hostel (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER UNIQUE,
        hostel_name TEXT,
        room_number TEXT,
        semester TEXT,
        academic_year TEXT,
        fee REAL,
        payment_status TEXT DEFAULT 'PENDING',
        FOREIGN KEY (student_id) REFERENCES Students(id)
      )
    `);

    // 8. HallTickets Table
    await runQuery(`
      CREATE TABLE IF NOT EXISTS HallTickets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER,
        examination TEXT NOT NULL,
        exam_date TEXT,
        exam_center TEXT,
        availability_status TEXT DEFAULT 'UNAVAILABLE',
        hall_ticket_url TEXT,
        FOREIGN KEY (student_id) REFERENCES Students(id)
      )
    `);

    // 9. AuditLogs Table
    await runQuery(`
      CREATE TABLE IF NOT EXISTS AuditLogs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        action TEXT NOT NULL,
        date DATETIME DEFAULT CURRENT_TIMESTAMP,
        record_id INTEGER,
        previous_value TEXT,
        new_value TEXT,
        FOREIGN KEY (user_id) REFERENCES Users(id)
      )
    `);

    console.log('Tables created successfully.');

    // Delete old unhashed demo user accounts if they exist
    await runQuery(`DELETE FROM Users WHERE email IN ('admin@bitm.edu.in', 'finance@bitm.edu.in', 'exam@bitm.edu.in', 'aparna@student.bitm.edu.in')`);

    // Insert Demo Data with bcrypt hashing
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash('password', saltRounds);

    // Super Admin
    await runQuery(`INSERT OR IGNORE INTO Users (id, name, email, password, role) VALUES (1, 'Super Admin', 'admin@bitm.edu.in', ?, 'SUPER_ADMIN')`, [hashedPassword]);
    
    // Finance Staff
    await runQuery(`INSERT OR IGNORE INTO Users (id, name, email, password, role) VALUES (2, 'Finance Admin', 'finance@bitm.edu.in', ?, 'FINANCE')`, [hashedPassword]);
    
    // Exam Staff
    await runQuery(`INSERT OR IGNORE INTO Users (id, name, email, password, role) VALUES (3, 'Exam Admin', 'exam@bitm.edu.in', ?, 'EXAM')`, [hashedPassword]);

    // Demo Student (Aparna Yadavalli)
    await runQuery(`INSERT OR IGNORE INTO Users (id, name, email, password, role) VALUES (4, 'Aparna Yadavalli', 'aparna@student.bitm.edu.in', ?, 'STUDENT')`, [hashedPassword]);
    await runQuery(`INSERT OR IGNORE INTO Students (id, user_id, usn, name, email, phone, branch, semester, academic_year, admission_category) 
      VALUES (1, 4, 'BITM2026XXXX', 'Aparna Yadavalli', 'aparna@student.bitm.edu.in', '9876543210', 'CSE - Data Science', '3rd Semester', '2026-27', 'K-CET')`);

    // Demo Registrations
    await runQuery(`INSERT OR IGNORE INTO Registrations (student_id, semester, academic_year, registration_status, payment_status) VALUES (1, '4th Semester', '2026-27', 'PENDING', 'PENDING')`);

    // Demo Payments
    await runQuery(`INSERT OR IGNORE INTO Payments (id, transaction_id, student_id, fee_category, amount, payment_method, status)
      VALUES (1, 'TXN100000001', 1, 'K-CET Admission', 95000, 'UPI', 'SUCCESS')`);
    
    // Demo Receipt
    await runQuery(`INSERT OR IGNORE INTO Receipts (id, receipt_number, payment_id, student_id)
      VALUES (1, 'REC20260001', 1, 1)`);

    console.log('Demo data inserted successfully.');

  } catch (error) {
    console.error('Error initializing database:', error);
  } finally {
    db.close();
  }
};

initDb();
