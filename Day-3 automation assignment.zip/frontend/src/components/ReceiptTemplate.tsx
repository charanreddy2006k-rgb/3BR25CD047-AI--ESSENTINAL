import React from 'react';
import { Building2 } from 'lucide-react';

interface ReceiptProps {
  receiptData: any;
  onClose?: () => void;
}

const ReceiptTemplate: React.FC<ReceiptProps> = ({ receiptData, onClose }) => {
  if (!receiptData) return null;

  return (
    <div className="bg-white p-8 max-w-3xl mx-auto border shadow-sm my-4 print:shadow-none print:border-none print:p-0">
      {/* Header aligned with standard formal receipts */}
      <div className="flex items-center justify-between border-b-2 border-[#1e3a8a] pb-4 mb-6">
        <div className="flex items-center">
          <Building2 className="h-12 w-12 text-[#1e3a8a] mr-4" />
          <div>
            <h1 className="text-xl font-bold text-[#1e3a8a]">BALLARI INSTITUTE OF TECHNOLOGY AND MANAGEMENT</h1>
            <p className="text-sm text-gray-600">(Recognised by Govt. of Karnataka, Affiliated to VTU Belagavi)</p>
            <p className="text-sm text-gray-600">Jnana Gangotri Campus, Ballari - 583104</p>
          </div>
        </div>
      </div>

      <div className="text-center mb-6">
        <h2 className="text-lg font-bold underline">FEE PAYMENT RECEIPT</h2>
      </div>

      <div className="flex justify-between mb-6 text-sm">
        <div>
          <p><span className="font-semibold">Receipt No:</span> {receiptData.receipt_number}</p>
          <p><span className="font-semibold">Transaction ID:</span> {receiptData.transaction_id}</p>
        </div>
        <div className="text-right">
          <p><span className="font-semibold">Date:</span> {new Date(receiptData.generated_date).toLocaleDateString('en-IN')}</p>
          <p><span className="font-semibold">Payment Mode:</span> {receiptData.payment_method}</p>
        </div>
      </div>

      <div className="border border-gray-300 rounded-md p-4 mb-6">
        <h3 className="font-semibold text-gray-700 border-b pb-2 mb-3">Student Details</h3>
        <div className="grid grid-cols-2 gap-y-2 text-sm">
          <div><span className="text-gray-500">Name:</span> <span className="font-medium">{receiptData.name}</span></div>
          <div><span className="text-gray-500">USN:</span> <span className="font-medium">{receiptData.usn}</span></div>
          <div><span className="text-gray-500">Branch:</span> <span className="font-medium">{receiptData.branch}</span></div>
          <div><span className="text-gray-500">Semester:</span> <span className="font-medium">{receiptData.semester}</span></div>
          <div><span className="text-gray-500">Academic Year:</span> <span className="font-medium">{receiptData.academic_year}</span></div>
        </div>
      </div>

      <table className="w-full mb-8 border-collapse border border-gray-300">
        <thead>
          <tr className="bg-gray-100">
            <th className="border border-gray-300 px-4 py-2 text-left">Sl No.</th>
            <th className="border border-gray-300 px-4 py-2 text-left">Fee Particulars</th>
            <th className="border border-gray-300 px-4 py-2 text-right">Amount (₹)</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className="border border-gray-300 px-4 py-2 text-center">1</td>
            <td className="border border-gray-300 px-4 py-2">{receiptData.fee_category}</td>
            <td className="border border-gray-300 px-4 py-2 text-right">{receiptData.amount.toLocaleString('en-IN')}</td>
          </tr>
          <tr className="font-bold bg-gray-50">
            <td colSpan={2} className="border border-gray-300 px-4 py-2 text-right">Total Amount Received</td>
            <td className="border border-gray-300 px-4 py-2 text-right">₹ {receiptData.amount.toLocaleString('en-IN')}</td>
          </tr>
        </tbody>
      </table>

      <div className="flex justify-between items-end mt-16 text-sm">
        <div className="w-32 h-32 bg-gray-100 flex items-center justify-center border border-gray-300">
          <span className="text-gray-400">QR Code</span>
        </div>
        <div className="text-center">
          <div className="w-40 border-b border-gray-800 mb-2"></div>
          <p className="font-semibold text-gray-700">Authorised Signatory</p>
          <p className="text-gray-500 text-xs mt-1">Finance / Accounts Dept.</p>
        </div>
      </div>

      <div className="mt-8 pt-4 border-t border-gray-200 text-xs text-center text-gray-500 print:hidden flex justify-center space-x-4">
        <button onClick={() => window.print()} className="bg-gray-800 text-white px-4 py-2 rounded hover:bg-gray-700">Print Receipt</button>
        {onClose && <button onClick={onClose} className="bg-gray-200 text-gray-800 px-4 py-2 rounded hover:bg-gray-300">Close</button>}
      </div>
    </div>
  );
};

export default ReceiptTemplate;
