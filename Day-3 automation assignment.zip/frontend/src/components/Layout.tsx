import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Link, useNavigate } from 'react-router-dom';
import { LogOut, User, GraduationCap, Building2 } from 'lucide-react';

const Layout = ({ children }: { children: React.ReactNode }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const getNavLinks = () => {
    if (!user) return [];
    
    switch (user.role) {
      case 'STUDENT':
        return [
          { name: 'Dashboard', path: '/student' },
          { name: 'Pay Fees', path: '/student/pay' },
          { name: 'Payments & Receipts', path: '/student/payments' },
          { name: 'Services (Bus/Hostel/Reg)', path: '/student/services' },
        ];
      case 'FINANCE':
        return [
          { name: 'Dashboard', path: '/finance' },
        ];
      case 'EXAM':
        return [
          { name: 'Dashboard', path: '/exam' },
        ];
      case 'SUPER_ADMIN':
        return [
          { name: 'Admin Dashboard', path: '/admin' },
          { name: 'Finance View', path: '/finance' },
          { name: 'Exam View', path: '/exam' },
        ];
      default:
        return [];
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="bg-[#1e3a8a] text-white shadow-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center space-x-3">
              <Building2 className="h-8 w-8 text-[#f59e0b]" />
              <div>
                <h1 className="text-xl font-bold leading-tight">BITM</h1>
                <p className="text-xs text-blue-200">Ballari Institute of Technology and Management</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 bg-blue-800 px-3 py-1.5 rounded-full">
                <User className="h-4 w-4" />
                <span className="text-sm font-medium">{user?.name} ({user?.role})</span>
              </div>
              <button 
                onClick={handleLogout}
                className="flex items-center space-x-1 hover:text-red-300 transition"
              >
                <LogOut className="h-5 w-5" />
                <span className="text-sm font-medium hidden sm:inline">Logout</span>
              </button>
            </div>
          </div>
        </div>
        
        {/* Navigation Bar */}
        <div className="bg-blue-900 border-t border-blue-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <nav className="flex space-x-1 overflow-x-auto py-2">
              {getNavLinks().map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className="px-3 py-2 rounded-md text-sm font-medium text-blue-100 hover:bg-blue-800 hover:text-white whitespace-nowrap transition"
                >
                  {link.name}
                </Link>
              ))}
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>

      <footer className="bg-white border-t border-gray-200 py-6 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-sm text-gray-500">
          &copy; {new Date().getFullYear()} Ballari Institute of Technology and Management. All rights reserved.
        </div>
      </footer>
    </div>
  );
};

export default Layout;
