import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Search, FileText } from 'lucide-react';
import ReceiptTemplate from '../../components/ReceiptTemplate';

const FinanceDashboard = () => {
  const [payments, setPayments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedReceipt, setSelectedReceipt] = useState<string | null>(null);
  const [receiptData, setReceiptData] = useState<any>(null);

  useEffect(() => {
    fetchPayments();
  }, []);

  const fetchPayments = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/admin/payments');
      setPayments(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleViewReceipt = async (receiptNumber: string) => {
    try {
      // For finance, we can reuse the same endpoint or create a specific admin one
      // The current endpoint /api/payments/receipt/:receiptNumber requires STUDENT role check bypass for admin,
      // Wait, in backend `payments.ts` receipt endpoint:
      // if (req.user.role === 'STUDENT' && receipt.student_id !== req.user.studentId) return 403
      // So admin CAN view it.
      const res = await axios.get(`http://localhost:5000/api/payments/receipt/${receiptNumber}`);
      setReceiptData(res.data);
      setSelectedReceipt(receiptNumber);
    } catch (err) {
      console.error(err);
      alert('Failed to load receipt details.');
    }
  };

  const filteredPayments = payments.filter(p => 
    p.usn?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.transaction_id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.receipt_number?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (selectedReceipt && receiptData) {
    return (
      <div className="max-w-4xl mx-auto">
        <button 
          onClick={() => setSelectedReceipt(null)}
          className="mb-4 text-blue-600 hover:text-blue-800 font-medium"
        >
          &larr; Back to Finance Dashboard
        </button>
        <ReceiptTemplate receiptData={receiptData} onClose={() => setSelectedReceipt(null)} />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Finance & Verification Portal</h1>
      </div>

      <div className="bg-white rounded-lg shadow mb-6 p-4 flex flex-col sm:flex-row sm:items-center justify-between border border-gray-200">
        <div className="relative flex-1 max-w-md">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-[#1e3a8a] focus:border-[#1e3a8a] sm:text-sm"
            placeholder="Search by USN, Name, TXN ID, Receipt No..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="mt-4 sm:mt-0 flex space-x-3">
          <button className="bg-green-600 text-white px-4 py-2 rounded text-sm hover:bg-green-700">Export Report</button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden border border-gray-200">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-[#1e3a8a] text-white">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Date</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Student Details</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Category & TXN</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Amount</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Status</th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {loading ? (
                <tr><td colSpan={6} className="px-6 py-4 text-center">Loading records...</td></tr>
              ) : filteredPayments.length === 0 ? (
                <tr><td colSpan={6} className="px-6 py-4 text-center text-gray-500">No matching payments found.</td></tr>
              ) : filteredPayments.map((payment) => (
                <tr key={payment.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(payment.payment_date).toLocaleDateString('en-IN')}
                    <div className="text-xs">{new Date(payment.payment_date).toLocaleTimeString('en-IN')}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{payment.name}</div>
                    <div className="text-sm text-gray-500">{payment.usn}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{payment.fee_category}</div>
                    <div className="text-xs text-gray-500">TXN: {payment.transaction_id}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900">
                    ₹{payment.amount.toLocaleString('en-IN')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      payment.status === 'SUCCESS' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {payment.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    {payment.receipt_number && payment.status === 'SUCCESS' ? (
                      <button 
                        onClick={() => handleViewReceipt(payment.receipt_number)}
                        className="text-indigo-600 hover:text-indigo-900 flex items-center justify-end"
                      >
                        <FileText className="h-4 w-4 mr-1" /> Receipt
                      </button>
                    ) : (
                      <span className="text-gray-400">N/A</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default FinanceDashboard;
