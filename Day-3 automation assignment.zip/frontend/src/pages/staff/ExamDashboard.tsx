import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Users, Ticket, BookOpen, PlusCircle } from 'lucide-react';

const ExamDashboard = () => {
  const [stats, setStats] = useState<any>(null);
  const [registrations, setRegistrations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [publishForm, setPublishForm] = useState(false);
  const [examName, setExamName] = useState('');
  const [examDate, setExamDate] = useState('');
  const [examCenter, setExamCenter] = useState('BITM Main Campus');
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const statsRes = await axios.get('http://localhost:5000/api/admin/stats');
      setStats(statsRes.data);
      
      const regRes = await axios.get('http://localhost:5000/api/admin/registrations');
      setRegistrations(regRes.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (id: number, currentStatus: string) => {
    const newStatus = currentStatus === 'COMPLETED' ? 'PENDING' : 'COMPLETED';
    try {
      await axios.post('http://localhost:5000/api/admin/registrations/update', { id, status: newStatus });
      fetchData(); // Refresh
    } catch (err) {
      alert('Failed to update status');
    }
  };

  const handlePublishHallTickets = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await axios.post('http://localhost:5000/api/admin/halltickets/publish', {
        examination: examName,
        exam_date: examDate,
        exam_center: examCenter
      });
      setMessage(`Successfully published ${res.data.published} hall tickets.`);
      setPublishForm(false);
      fetchData();
    } catch (err) {
      alert('Failed to publish hall tickets');
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Examination & Academic Portal</h1>
      
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6 border-l-4 border-indigo-500">
            <div className="flex items-center">
              <Users className="h-10 w-10 text-indigo-500 mr-4" />
              <div>
                <h3 className="text-lg font-semibold text-gray-700">Eligible Students</h3>
                <p className="text-2xl font-bold text-gray-900">{stats.totalStudents}</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6 border-l-4 border-red-500">
            <div className="flex items-center">
              <Ticket className="h-10 w-10 text-red-500 mr-4" />
              <div>
                <h3 className="text-lg font-semibold text-gray-700">Hall Tickets Published</h3>
                <p className="text-2xl font-bold text-gray-900">{stats.publishedHallTickets}</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6 border-l-4 border-green-500">
            <div className="flex items-center">
              <BookOpen className="h-10 w-10 text-green-500 mr-4" />
              <div>
                <h3 className="text-lg font-semibold text-gray-700">Registrations Completed</h3>
                <p className="text-2xl font-bold text-gray-900">{stats.totalRegistrations}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {message && (
        <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded">
          {message}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-lg shadow border border-gray-200 overflow-hidden">
          <div className="p-4 border-b bg-gray-50 flex justify-between items-center">
            <h2 className="text-lg font-semibold text-gray-800">Higher Semester Registrations</h2>
          </div>
          <div className="overflow-x-auto p-4">
            <table className="min-w-full divide-y divide-gray-200">
              <thead>
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Student</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Semester</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                  <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {registrations.length === 0 ? (
                  <tr><td colSpan={4} className="px-4 py-4 text-center text-gray-500">No registrations found.</td></tr>
                ) : registrations.map((reg) => (
                  <tr key={reg.id}>
                    <td className="px-4 py-3">
                      <div className="text-sm font-medium text-gray-900">{reg.name}</div>
                      <div className="text-xs text-gray-500">{reg.usn}</div>
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-500">{reg.semester}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        reg.registration_status === 'COMPLETED' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {reg.registration_status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button 
                        onClick={() => handleUpdateStatus(reg.id, reg.registration_status)}
                        className="text-sm text-indigo-600 hover:text-indigo-900"
                      >
                        Toggle Status
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow border border-gray-200 h-fit">
          <div className="p-4 border-b bg-gray-50 flex justify-between items-center">
            <h2 className="text-lg font-semibold text-gray-800">Publish Hall Tickets</h2>
          </div>
          <div className="p-6">
            {!publishForm ? (
              <button 
                onClick={() => setPublishForm(true)}
                className="w-full flex items-center justify-center py-3 border-2 border-dashed border-gray-300 rounded-md text-gray-600 hover:border-indigo-500 hover:text-indigo-500 transition"
              >
                <PlusCircle className="h-5 w-5 mr-2" /> Publish New Hall Ticket
              </button>
            ) : (
              <form onSubmit={handlePublishHallTickets} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Examination Name</label>
                  <input type="text" required value={examName} onChange={e => setExamName(e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" placeholder="e.g. 3rd Sem Main Exam 2026" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Start Date</label>
                  <input type="date" required value={examDate} onChange={e => setExamDate(e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Exam Center</label>
                  <input type="text" required value={examCenter} onChange={e => setExamCenter(e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
                </div>
                <div className="flex justify-end space-x-3 pt-2">
                  <button type="button" onClick={() => setPublishForm(false)} className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">Cancel</button>
                  <button type="submit" className="bg-indigo-600 py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">Publish All</button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExamDashboard;
