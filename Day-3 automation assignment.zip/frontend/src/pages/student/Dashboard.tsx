import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import axios from 'axios';
import { 
  CreditCard, 
  History, 
  FileText, 
  BookOpen, 
  Ticket, 
  BusFront, 
  Building, 
  User 
} from 'lucide-react';

const StudentDashboard = () => {
  const { user } = useAuth();
  const [profile, setProfile] = useState<any>(null);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/students/profile');
        setProfile(res.data);
      } catch (err) {
        console.error('Failed to fetch profile', err);
      }
    };
    fetchProfile();
  }, []);

  const cards = [
    { title: 'Pay Fees', icon: <CreditCard className="h-8 w-8 text-blue-600" />, path: '/student/pay', desc: 'Pay admission, exam, or other fees' },
    { title: 'Payment History', icon: <History className="h-8 w-8 text-green-600" />, path: '/student/payments', desc: 'View your previous transactions' },
    { title: 'Receipts', icon: <FileText className="h-8 w-8 text-purple-600" />, path: '/student/payments', desc: 'Download fee receipts' },
    { title: 'Higher Sem Registration', icon: <BookOpen className="h-8 w-8 text-indigo-600" />, path: '/student/services', desc: 'Register for next semester' },
    { title: 'Hall Ticket', icon: <Ticket className="h-8 w-8 text-red-600" />, path: '/student/services', desc: 'Download exam hall ticket' },
    { title: 'Bus Fee', icon: <BusFront className="h-8 w-8 text-yellow-600" />, path: '/student/services', desc: 'Manage transportation' },
    { title: 'Hostel Fee', icon: <Building className="h-8 w-8 text-teal-600" />, path: '/student/services', desc: 'Manage accommodation' },
    { title: 'Profile', icon: <User className="h-8 w-8 text-gray-600" />, path: '#profile', desc: 'View academic details' },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow p-6 border-l-4 border-[#1e3a8a]">
        <h2 className="text-2xl font-bold text-gray-800 mb-4" id="profile">Welcome, {user?.name}</h2>
        {profile ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
            <div><span className="text-gray-500 block">USN</span><span className="font-semibold text-gray-900">{profile.usn}</span></div>
            <div><span className="text-gray-500 block">Branch</span><span className="font-semibold text-gray-900">{profile.branch}</span></div>
            <div><span className="text-gray-500 block">Semester</span><span className="font-semibold text-gray-900">{profile.semester}</span></div>
            <div><span className="text-gray-500 block">Academic Year</span><span className="font-semibold text-gray-900">{profile.academic_year}</span></div>
            <div><span className="text-gray-500 block">Email</span><span className="font-semibold text-gray-900">{profile.email}</span></div>
            <div><span className="text-gray-500 block">Phone</span><span className="font-semibold text-gray-900">{profile.phone}</span></div>
            <div><span className="text-gray-500 block">Admission Type</span><span className="font-semibold text-gray-900">{profile.admission_category}</span></div>
          </div>
        ) : (
          <p className="text-gray-500">Loading profile information...</p>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((card, idx) => (
          <Link to={card.path} key={idx} className="bg-white rounded-lg shadow hover:shadow-md transition-shadow p-6 flex flex-col items-center text-center border border-gray-100 group">
            <div className="bg-gray-50 p-4 rounded-full mb-4 group-hover:bg-blue-50 transition-colors">
              {card.icon}
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">{card.title}</h3>
            <p className="text-sm text-gray-500">{card.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default StudentDashboard;
