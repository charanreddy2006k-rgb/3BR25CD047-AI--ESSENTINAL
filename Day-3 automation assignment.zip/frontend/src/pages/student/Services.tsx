import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { BookOpen, Ticket, BusFront, Building, Download } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';

const Services = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [data, setData] = useState({
    bus: null as any,
    hostel: null as any,
    registration: null as any,
    hallTickets: [] as any[]
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchServices = async () => {
      try {
        const [busRes, hostelRes, regRes, htRes] = await Promise.all([
          axios.get('http://localhost:5000/api/students/bus').catch(() => ({ data: null })),
          axios.get('http://localhost:5000/api/students/hostel').catch(() => ({ data: null })),
          axios.get('http://localhost:5000/api/students/registration').catch(() => ({ data: null })),
          axios.get('http://localhost:5000/api/students/halltickets').catch(() => ({ data: [] }))
        ]);

        setData({
          bus: busRes.data,
          hostel: hostelRes.data,
          registration: regRes.data,
          hallTickets: htRes.data
        });
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchServices();
  }, []);

  const handleStartRegistration = () => {
    navigate('/student/pay', { state: { category: 'Higher Semester Fee' } });
  };

  const handleApplyBus = () => {
    navigate('/student/pay', { state: { category: 'Bus Fee' } });
  };

  const handleApplyHostel = () => {
    navigate('/student/pay', { state: { category: 'Hostel Fee' } });
  };

  const downloadHallTicket = (ht: any) => {
    alert(`Downloading Hall Ticket for ${ht.examination}. This would generate a PDF.`);
  };

  if (loading) return <div>Loading...</div>;

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Student Services</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Higher Sem Registration */}
        <div className="bg-white rounded-lg shadow border border-gray-200">
          <div className="p-4 border-b bg-indigo-50 flex items-center">
            <BookOpen className="h-6 w-6 text-indigo-600 mr-2" />
            <h2 className="text-lg font-semibold text-gray-800">Higher Semester Registration</h2>
          </div>
          <div className="p-6">
            {data.registration ? (
              <div className="space-y-3">
                <div className="flex justify-between"><span className="text-gray-500">Target Semester:</span> <span className="font-medium">{data.registration.semester}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Academic Year:</span> <span className="font-medium">{data.registration.academic_year}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Registration Status:</span> 
                  <span className={`font-semibold ${data.registration.registration_status === 'COMPLETED' ? 'text-green-600' : 'text-yellow-600'}`}>
                    {data.registration.registration_status.replace('_', ' ')}
                  </span>
                </div>
                {data.registration.registration_status !== 'COMPLETED' && (
                  <button onClick={handleStartRegistration} className="mt-4 w-full bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Start Registration Process</button>
                )}
              </div>
            ) : (
              <div className="text-center">
                <p className="text-gray-500 py-4">No active registration cycles found, or you are not eligible.</p>
                <button onClick={handleStartRegistration} className="mt-2 text-sm bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Manually Pay Higher Sem Fee</button>
              </div>
            )}
          </div>
        </div>

        {/* Hall Tickets */}
        <div className="bg-white rounded-lg shadow border border-gray-200">
          <div className="p-4 border-b bg-red-50 flex items-center">
            <Ticket className="h-6 w-6 text-red-600 mr-2" />
            <h2 className="text-lg font-semibold text-gray-800">Hall Tickets</h2>
          </div>
          <div className="p-6">
            {data.hallTickets && data.hallTickets.length > 0 ? (
              <ul className="space-y-4">
                {data.hallTickets.map((ht: any) => (
                  <li key={ht.id} className="flex justify-between items-center border-b pb-3 last:border-0">
                    <div>
                      <p className="font-semibold text-gray-800">{ht.examination}</p>
                      <p className="text-sm text-gray-500">Date: {ht.exam_date} | Center: {ht.exam_center}</p>
                    </div>
                    {ht.availability_status === 'AVAILABLE' ? (
                      <button onClick={() => downloadHallTicket(ht)} className="flex items-center text-sm bg-red-100 text-red-700 px-3 py-1.5 rounded hover:bg-red-200">
                        <Download className="h-4 w-4 mr-1" /> Download
                      </button>
                    ) : (
                      <span className="text-sm text-gray-400 border px-2 py-1 rounded">Not Released</span>
                    )}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-gray-500 text-center py-4">No hall tickets currently available.</p>
            )}
          </div>
        </div>

        {/* Bus Service */}
        <div className="bg-white rounded-lg shadow border border-gray-200">
          <div className="p-4 border-b bg-yellow-50 flex items-center">
            <BusFront className="h-6 w-6 text-yellow-600 mr-2" />
            <h2 className="text-lg font-semibold text-gray-800">Bus / Transportation</h2>
          </div>
          <div className="p-6">
            {data.bus ? (
              <div className="space-y-3">
                <div className="flex justify-between"><span className="text-gray-500">Route:</span> <span className="font-medium">{data.bus.route}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Pickup Point:</span> <span className="font-medium">{data.bus.pickup_point}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Fee Amount:</span> <span className="font-medium">₹{data.bus.fee?.toLocaleString('en-IN')}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Payment Status:</span> 
                  <span className={`font-semibold ${data.bus.payment_status === 'SUCCESS' ? 'text-green-600' : 'text-red-600'}`}>
                    {data.bus.payment_status}
                  </span>
                </div>
              </div>
            ) : (
              <div className="text-center">
                <p className="text-gray-500 py-4">You are not registered for the bus service.</p>
                <button onClick={handleApplyBus} className="bg-yellow-600 text-white px-4 py-2 rounded hover:bg-yellow-700 text-sm">Apply for Bus Pass & Pay</button>
              </div>
            )}
          </div>
        </div>

        {/* Hostel Service */}
        <div className="bg-white rounded-lg shadow border border-gray-200">
          <div className="p-4 border-b bg-teal-50 flex items-center">
            <Building className="h-6 w-6 text-teal-600 mr-2" />
            <h2 className="text-lg font-semibold text-gray-800">Hostel Accommodation</h2>
          </div>
          <div className="p-6">
            {data.hostel ? (
              <div className="space-y-3">
                <div className="flex justify-between"><span className="text-gray-500">Hostel Name:</span> <span className="font-medium">{data.hostel.hostel_name}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Room Number:</span> <span className="font-medium">{data.hostel.room_number}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Fee Amount:</span> <span className="font-medium">₹{data.hostel.fee?.toLocaleString('en-IN')}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Payment Status:</span> 
                  <span className={`font-semibold ${data.hostel.payment_status === 'SUCCESS' ? 'text-green-600' : 'text-red-600'}`}>
                    {data.hostel.payment_status}
                  </span>
                </div>
              </div>
            ) : (
              <div className="text-center">
                <p className="text-gray-500 py-4">You are not registered for hostel accommodation.</p>
                <button onClick={handleApplyHostel} className="bg-teal-600 text-white px-4 py-2 rounded hover:bg-teal-700 text-sm">Apply for Hostel & Pay</button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Services;
