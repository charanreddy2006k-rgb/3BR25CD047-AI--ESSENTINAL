import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../../context/AuthContext';
import { useNavigate, useLocation } from 'react-router-dom';
import { CreditCard, Smartphone, CheckCircle, AlertCircle } from 'lucide-react';

const feeCategories = [
  { id: 'Management Quota', name: 'Management Quota', amount: 150000 },
  { id: 'K-CET Admission', name: 'K-CET Admission', amount: 95000 },
  { id: 'Exam Fees', name: 'Exam Fees', amount: 2500 },
  { id: 'Higher Semester Fee', name: 'Higher Semester Fee', amount: 85000 },
  { id: 'Bus Fee', name: 'Bus Fee', amount: 12000 },
  { id: 'Hostel Fee', name: 'Hostel Fee', amount: 45000 },
];

const PaymentFlow = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [step, setStep] = useState(1);
  const [selectedFee, setSelectedFee] = useState<any>(null);
  const [paymentMethod, setPaymentMethod] = useState('UPI');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [successData, setSuccessData] = useState<any>(null);

  useEffect(() => {
    // Check if category was passed from Services page
    if (location.state && location.state.category) {
      const preselected = feeCategories.find(c => c.id === location.state.category);
      if (preselected) {
        setSelectedFee(preselected);
        setStep(2);
      }
    }
  }, [location]);

  const handleProcessPayment = async () => {
    setLoading(true);
    setError('');
    try {
      // Simulate network delay for demo
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const res = await axios.post('http://localhost:5000/api/payments/process', {
        fee_category: selectedFee.name,
        amount: selectedFee.amount,
        payment_method: paymentMethod
      });
      
      setSuccessData(res.data);
      setStep(4);
    } catch (err) {
      setError('Payment could not be completed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Fee Payment</h1>
        <div className="flex items-center mt-4">
          {[1, 2, 3, 4].map((s) => (
            <div key={s} className="flex items-center">
              <div className={`h-8 w-8 rounded-full flex items-center justify-center font-semibold text-sm ${
                step >= s ? 'bg-[#1e3a8a] text-white' : 'bg-gray-200 text-gray-600'
              }`}>
                {s}
              </div>
              {s < 4 && (
                <div className={`h-1 w-16 mx-2 ${step > s ? 'bg-[#1e3a8a]' : 'bg-gray-200'}`}></div>
              )}
            </div>
          ))}
        </div>
      </div>

      {error && (
        <div className="mb-4 bg-red-50 border-l-4 border-red-500 p-4 flex items-center">
          <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
          <p className="text-red-700">{error}</p>
        </div>
      )}

      {/* Step 1: Select Category */}
      {step === 1 && (
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Select Fee Category</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {feeCategories.map(fee => (
              <div 
                key={fee.id}
                onClick={() => setSelectedFee(fee)}
                className={`p-4 rounded-lg border-2 cursor-pointer transition ${
                  selectedFee?.id === fee.id ? 'border-[#1e3a8a] bg-blue-50' : 'border-gray-200 hover:border-blue-300'
                }`}
              >
                <div className="flex justify-between items-center">
                  <span className="font-medium text-gray-900">{fee.name}</span>
                  <span className="font-bold text-[#1e3a8a]">₹{fee.amount.toLocaleString('en-IN')}</span>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6 flex justify-end">
            <button 
              disabled={!selectedFee}
              onClick={() => setStep(2)}
              className="bg-[#1e3a8a] text-white px-6 py-2 rounded-md hover:bg-blue-800 disabled:opacity-50 transition"
            >
              Continue
            </button>
          </div>
        </div>
      )}

      {/* Step 2: Confirm Details */}
      {step === 2 && (
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Verify Details</h2>
          <div className="bg-gray-50 rounded-lg p-6 mb-6">
            <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-6">
              <div><dt className="text-sm font-medium text-gray-500">Student Name</dt><dd className="mt-1 text-sm text-gray-900">{user?.name}</dd></div>
              <div><dt className="text-sm font-medium text-gray-500">USN</dt><dd className="mt-1 text-sm text-gray-900">{user?.student?.usn}</dd></div>
              <div><dt className="text-sm font-medium text-gray-500">Fee Category</dt><dd className="mt-1 text-sm text-gray-900">{selectedFee.name}</dd></div>
              <div><dt className="text-sm font-medium text-gray-500">Amount Payable</dt><dd className="mt-1 text-lg font-bold text-[#1e3a8a]">₹{selectedFee.amount.toLocaleString('en-IN')}</dd></div>
            </dl>
          </div>
          <div className="flex justify-between">
            <button onClick={() => setStep(1)} className="text-gray-600 hover:text-gray-900 px-4 py-2 border rounded-md">Back</button>
            <button onClick={() => setStep(3)} className="bg-[#1e3a8a] text-white px-6 py-2 rounded-md hover:bg-blue-800 transition">Proceed to Pay</button>
          </div>
        </div>
      )}

      {/* Step 3: Payment Gateway Demo */}
      {step === 3 && (
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Payment Information (Demo)</h2>
          <div className="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-md text-sm text-yellow-800">
            <strong>Note:</strong> This is a demo payment gateway. No real money will be deducted.
          </div>
          
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">Select Payment Method</label>
            <div className="grid grid-cols-2 gap-4">
              <div 
                onClick={() => setPaymentMethod('UPI')}
                className={`flex items-center p-4 border rounded-md cursor-pointer ${paymentMethod === 'UPI' ? 'border-[#1e3a8a] bg-blue-50' : 'border-gray-200'}`}
              >
                <Smartphone className="h-6 w-6 mr-3 text-gray-600" />
                <span className="font-medium">UPI</span>
              </div>
              <div 
                onClick={() => setPaymentMethod('Card')}
                className={`flex items-center p-4 border rounded-md cursor-pointer ${paymentMethod === 'Card' ? 'border-[#1e3a8a] bg-blue-50' : 'border-gray-200'}`}
              >
                <CreditCard className="h-6 w-6 mr-3 text-gray-600" />
                <span className="font-medium">Debit / Credit Card</span>
              </div>
            </div>
          </div>

          {paymentMethod === 'UPI' && (
            <div className="flex justify-center mb-6">
              <div className="p-4 bg-gray-100 rounded-lg text-center">
                <div className="w-48 h-48 bg-gray-300 mx-auto mb-2 flex items-center justify-center text-gray-500">
                  [Demo QR Code]
                </div>
                <p className="text-sm text-gray-600">Scan using any UPI App</p>
                <p className="font-bold text-lg mt-2">₹{selectedFee.amount.toLocaleString('en-IN')}</p>
              </div>
            </div>
          )}

          <div className="flex justify-between">
            <button onClick={() => setStep(2)} className="text-gray-600 hover:text-gray-900 px-4 py-2 border rounded-md" disabled={loading}>Cancel</button>
            <button 
              onClick={handleProcessPayment} 
              disabled={loading}
              className="bg-green-600 text-white px-8 py-2 rounded-md hover:bg-green-700 transition flex items-center disabled:opacity-70"
            >
              {loading ? 'Processing...' : `Pay ₹${selectedFee.amount.toLocaleString('en-IN')}`}
            </button>
          </div>
        </div>
      )}

      {/* Step 4: Success */}
      {step === 4 && successData && (
        <div className="bg-white rounded-lg shadow p-8 text-center">
          <div className="flex justify-center mb-4">
            <CheckCircle className="h-16 w-16 text-green-500" />
          </div>
          <h2 className="text-3xl font-bold text-green-600 mb-2">Payment Successful ✓</h2>
          <p className="text-gray-600 mb-8">Your fee payment has been successfully processed.</p>
          
          <div className="bg-gray-50 p-4 rounded-lg inline-block text-left mb-8 min-w-[300px]">
            <div className="flex justify-between mb-2">
              <span className="text-gray-500">Transaction ID:</span>
              <span className="font-medium">{successData.transaction_id}</span>
            </div>
            <div className="flex justify-between mb-2">
              <span className="text-gray-500">Receipt No:</span>
              <span className="font-medium">{successData.receipt_number}</span>
            </div>
            <div className="flex justify-between mb-2">
              <span className="text-gray-500">Amount Paid:</span>
              <span className="font-medium">₹{selectedFee.amount.toLocaleString('en-IN')}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Status:</span>
              <span className="font-medium text-green-600">SUCCESS</span>
            </div>
          </div>
          
          <div className="flex justify-center space-x-4">
            <button onClick={() => navigate('/student/payments')} className="bg-[#1e3a8a] text-white px-6 py-2 rounded-md hover:bg-blue-800 transition">
              View Receipt
            </button>
            <button onClick={() => navigate('/student')} className="text-[#1e3a8a] bg-blue-50 px-6 py-2 rounded-md hover:bg-blue-100 transition border border-blue-200">
              Go to Dashboard
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PaymentFlow;
