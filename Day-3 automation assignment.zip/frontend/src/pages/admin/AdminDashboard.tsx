import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Users, DollarSign, Activity, CheckCircle, Database, Settings } from 'lucide-react';

const AdminDashboard = () => {
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/admin/stats');
        setStats(res.data);
      } catch (err) {
        console.error(err);
      }
    };
    fetchStats();
  }, []);

  const handleFeatureClick = () => {
    alert("This feature would open a dedicated management module in a complete implementation.");
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Super Admin Dashboard</h1>

      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white rounded-lg shadow p-6 border border-gray-100 flex items-center">
            <div className="p-3 bg-blue-100 text-blue-600 rounded-full mr-4"><Users className="h-6 w-6" /></div>
            <div>
              <p className="text-sm font-medium text-gray-500">Total Students</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalStudents}</p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6 border border-gray-100 flex items-center">
            <div className="p-3 bg-green-100 text-green-600 rounded-full mr-4"><DollarSign className="h-6 w-6" /></div>
            <div>
              <p className="text-sm font-medium text-gray-500">Total Collection</p>
              <p className="text-2xl font-bold text-gray-900">₹{stats.totalCollection.toLocaleString('en-IN')}</p>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6 border border-gray-100 flex items-center">
            <div className="p-3 bg-purple-100 text-purple-600 rounded-full mr-4"><Activity className="h-6 w-6" /></div>
            <div>
              <p className="text-sm font-medium text-gray-500">Total Transactions</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalPayments}</p>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6 border border-gray-100 flex items-center">
            <div className="p-3 bg-teal-100 text-teal-600 rounded-full mr-4"><CheckCircle className="h-6 w-6" /></div>
            <div>
              <p className="text-sm font-medium text-gray-500">Successful Payments</p>
              <p className="text-2xl font-bold text-gray-900">{stats.successfulPayments}</p>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
        <div className="bg-white rounded-lg shadow p-6 border border-gray-200 col-span-2">
          <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
            <Database className="h-5 w-5 mr-2 text-[#1e3a8a]" /> System Administration Modules
          </h2>
          <div className="grid grid-cols-2 gap-4">
            <button onClick={handleFeatureClick} className="p-4 border rounded hover:bg-gray-50 text-left font-medium transition">Manage Users & Roles</button>
            <button onClick={handleFeatureClick} className="p-4 border rounded hover:bg-gray-50 text-left font-medium transition">Manage Students</button>
            <button onClick={handleFeatureClick} className="p-4 border rounded hover:bg-gray-50 text-left font-medium transition">Fee Structures</button>
            <button onClick={handleFeatureClick} className="p-4 border rounded hover:bg-gray-50 text-left font-medium transition">Academic Configuration</button>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6 border border-gray-200">
          <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
            <Settings className="h-5 w-5 mr-2 text-gray-600" /> Recent Audit Logs
          </h2>
          <div className="space-y-4">
            <div className="text-sm border-b pb-2">
              <span className="font-semibold text-gray-800">Finance Admin</span> verified payment TXN100000001
              <div className="text-xs text-gray-500">10 mins ago</div>
            </div>
            <div className="text-sm border-b pb-2">
              <span className="font-semibold text-gray-800">Super Admin</span> updated Management Quota fee
              <div className="text-xs text-gray-500">1 hour ago</div>
            </div>
            <div className="text-sm">
              <span className="font-semibold text-gray-800">Exam Admin</span> published 3rd Sem Hall Tickets
              <div className="text-xs text-gray-500">2 hours ago</div>
            </div>
          </div>
          <button onClick={handleFeatureClick} className="mt-4 text-[#1e3a8a] text-sm font-medium hover:underline">View All Logs</button>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
