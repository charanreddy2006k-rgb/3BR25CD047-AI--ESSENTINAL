import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import Login from './pages/Login';
import StudentDashboard from './pages/student/Dashboard';
import PaymentFlow from './pages/student/PaymentFlow';
import PaymentHistory from './pages/student/PaymentHistory';
import Services from './pages/student/Services';
import FinanceDashboard from './pages/staff/FinanceDashboard';
import ExamDashboard from './pages/staff/ExamDashboard';
import AdminDashboard from './pages/admin/AdminDashboard';
import Layout from './components/Layout';

const ProtectedRoute = ({ children, allowedRoles }: { children: JSX.Element, allowedRoles: string[] }) => {
  const { user, token } = useAuth();
  
  if (!token) return <Navigate to="/login" replace />;
  if (user && !allowedRoles.includes(user.role)) return <Navigate to="/unauthorized" replace />;
  
  return children;
};

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        
        {/* Student Routes */}
        <Route path="/student" element={
          <ProtectedRoute allowedRoles={['STUDENT']}>
            <Layout><StudentDashboard /></Layout>
          </ProtectedRoute>
        } />
        <Route path="/student/pay" element={
          <ProtectedRoute allowedRoles={['STUDENT']}>
            <Layout><PaymentFlow /></Layout>
          </ProtectedRoute>
        } />
        <Route path="/student/payments" element={
          <ProtectedRoute allowedRoles={['STUDENT']}>
            <Layout><PaymentHistory /></Layout>
          </ProtectedRoute>
        } />
        <Route path="/student/services" element={
          <ProtectedRoute allowedRoles={['STUDENT']}>
            <Layout><Services /></Layout>
          </ProtectedRoute>
        } />

        {/* Staff Routes */}
        <Route path="/finance" element={
          <ProtectedRoute allowedRoles={['FINANCE', 'SUPER_ADMIN']}>
            <Layout><FinanceDashboard /></Layout>
          </ProtectedRoute>
        } />
        <Route path="/exam" element={
          <ProtectedRoute allowedRoles={['EXAM', 'SUPER_ADMIN']}>
            <Layout><ExamDashboard /></Layout>
          </ProtectedRoute>
        } />

        {/* Admin Routes */}
        <Route path="/admin" element={
          <ProtectedRoute allowedRoles={['SUPER_ADMIN']}>
            <Layout><AdminDashboard /></Layout>
          </ProtectedRoute>
        } />

        {/* Catch-all */}
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="/unauthorized" element={<div className="p-10 text-center">Unauthorized Access</div>} />
      </Routes>
    </Router>
  );
}

export default App;
